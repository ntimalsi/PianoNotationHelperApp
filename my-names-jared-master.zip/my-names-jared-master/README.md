# my-names-jared
A virtual keyboard made with p5.js to teach correlation between piano keys and notes on a staff. 
The live demo: http://madelynvagle.me/my-names-jared/

The repository name comes from this vine: https://www.youtube.com/watch?v=CqCCBohjaqA. 

Because we're teaching people to read sheet music. 

The web version is implemented through the sketch.js file and index.html. The Android app progress is under the /src and /lib directories. 

# initial goals 
Our initial idea was for an android app that intuitively linked the familiarity of the piano with reading sheet music. 

# thoughts
### madelyn
I thought about using Processing to add the notes to the staff as the user taps the keys. I'm more familiar with JavaScript than
Android, so I decided to write my original script for web. Processing was also appealing because of it's capabilities in visualizing auditory
data. Not only did p5.js meet the needs of the program, it offered potential to interact with the art theme of the hackathon. 


### Functionality / Issues
need support for sharps and flats
need to make layout more responsive/centered on larger screens + tablet. 
mobile vertical constraints 
